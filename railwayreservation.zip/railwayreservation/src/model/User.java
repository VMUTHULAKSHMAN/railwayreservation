package model;

public class User {

}
