package model;

public class Train {

}
