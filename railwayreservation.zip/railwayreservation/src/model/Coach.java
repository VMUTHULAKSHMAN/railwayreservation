package model;

public class Coach {

}
